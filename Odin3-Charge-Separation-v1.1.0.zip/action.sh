#!/system/bin/sh
# action.sh - "Action" button in Magisk app: live status
# Module by KingAether

DATADIR=/data/adb/charge_sep
BATT=/sys/class/power_supply/battery
CCEN=/sys/class/qcom-battery/charge_control_en

echo "=== Odin 3 Charge Separation (KingAether) ==="
echo "Battery:    $(cat $BATT/capacity 2>/dev/null)%  ($(cat $BATT/status 2>/dev/null))"
echo "Current:    $(cat $BATT/current_now 2>/dev/null) uA (negative = discharging)"
echo "State:      $(cat $DATADIR/state 2>/dev/null || echo unknown)"
if [ -f "$DATADIR/daemon.pid" ] && kill -0 "$(cat $DATADIR/daemon.pid)" 2>/dev/null; then
  echo "Daemon:     running (pid $(cat $DATADIR/daemon.pid))"
else
  echo "Daemon:     NOT RUNNING"
fi
echo "charge_control_en:  $(cat $CCEN 2>/dev/null)"
echo "end_threshold:      $(cat $BATT/charge_control_end_threshold 2>/dev/null)"
echo "start_threshold:    $(cat $BATT/charge_control_start_threshold 2>/dev/null)"
. $DATADIR/config.conf 2>/dev/null
echo "Config:     TARGET=$TARGET RESUME=$RESUME POLL=${POLL}s"
echo ""
echo "Last log lines:"
tail -n 8 $DATADIR/daemon.log 2>/dev/null

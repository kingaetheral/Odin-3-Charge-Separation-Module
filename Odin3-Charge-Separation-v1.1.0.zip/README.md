# Odin 3 Charge Separation @ 100%
**by KingAether** — v1.1.0

A Magisk module for the AYN Odin 3 that engages **charge separation** (battery-idle / bypass charging) at 100%, using the kernel's *native* charge-control interface discovered on the device:

- `/sys/class/qcom-battery/charge_control_en` — master enable
- `/sys/class/power_supply/battery/charge_control_end_threshold` — stop-charging %
- `/sys/class/power_supply/battery/charge_control_start_threshold` — resume-charging %

Because the charger firmware enforces these itself, separation works **even with the screen off / in deep sleep** — the daemon just keeps the thresholds set (AYN's own service or a charger replug can silently rewrite them, so it re-enforces every 30s).

## Install
1. Magisk → Modules → Install from storage → flash the zip.
2. Reboot.
3. Tap the module's **Action** button in Magisk for live status (battery %, current draw, threshold values, log).

## Configuration
`/data/adb/charge_sep/config.conf`:
```
TARGET=100   # stop charging at this %
RESUME=97    # resume charging at this %
POLL=30      # seconds between enforcement checks
```
Edit, then reboot (or kill the daemon; it restarts on boot).

**If separation never engages at 100%:** some kernels treat `end_threshold=100` as "charge fully / feature disabled." Set `TARGET=99` — in practice the battery sits at 99–100% anyway.

**Battery-health tip:** `TARGET=80` / `RESUME=70` (the values AYN ships with) is far kinder to the cell long-term than parking at 100%.

## Verifying it works
Plug in, let it hit your target, then check the Action button: status should read `Not charging` / `Full` while `current_now` hovers near zero or positive — that means the system is running off the wall, battery idle.

## Uninstall
Remove the module in Magisk. The uninstall script restores the exact threshold values your device shipped with (saved on first run) and kills the daemon.

## Disclaimer
These sysfs nodes exist precisely for userspace charge control and are the same mechanism AYN's own software uses, but flash at your own risk.

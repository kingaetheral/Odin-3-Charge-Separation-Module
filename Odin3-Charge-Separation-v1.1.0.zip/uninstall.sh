#!/system/bin/sh
# uninstall.sh - restore original charging config when module is removed
# Module by KingAether

DATADIR=/data/adb/charge_sep
CONF=$DATADIR/config.conf
ORIG=$DATADIR/original_values

CCEN=/sys/class/qcom-battery/charge_control_en
END_NODE=/sys/class/power_supply/battery/charge_control_end_threshold
START_NODE=/sys/class/power_supply/battery/charge_control_start_threshold

# Kill the daemon if running
[ -f "$DATADIR/daemon.pid" ] && kill "$(cat $DATADIR/daemon.pid)" 2>/dev/null

# Restore the values the device shipped with (saved at first daemon start)
if [ -f "$ORIG" ]; then
  . "$ORIG"
  [ -n "$ORIG_END" ]   && [ -f "$END_NODE" ]   && echo "$ORIG_END"   > "$END_NODE"   2>/dev/null
  [ -n "$ORIG_START" ] && [ -f "$START_NODE" ] && echo "$ORIG_START" > "$START_NODE" 2>/dev/null
  [ -n "$ORIG_CCEN" ]  && [ -f "$CCEN" ]       && echo "$ORIG_CCEN"  > "$CCEN"       2>/dev/null
fi

# Legacy fallback: re-enable charging on any configured on/off node
NODE=""; NODE_RESUME=""
[ -f "$CONF" ] && . "$CONF"
[ -n "$NODE" ] && [ -f "$NODE" ] && echo "$NODE_RESUME" > "$NODE" 2>/dev/null

rm -rf "$DATADIR"

#!/system/bin/sh
# service.sh - late_start service, runs at boot as root

MODDIR=${0%/*}
DATADIR=/data/adb/charge_sep
mkdir -p $DATADIR

# Wait until boot is fully complete
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done
# Give the battery service a moment to settle
sleep 15

# Kill any stale instance, then launch the daemon detached
PIDFILE=$DATADIR/daemon.pid
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$OLD" ] && kill "$OLD" 2>/dev/null
fi

nohup $MODDIR/system/bin/charge_sep_daemon > /dev/null 2>&1 &
echo $! > "$PIDFILE"

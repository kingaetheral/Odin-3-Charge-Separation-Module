#!/system/bin/sh
# customize.sh - runs at module install time (v1.1.0)

SKIPUNZIP=0

DATADIR=/data/adb/charge_sep
CONF=$DATADIR/config.conf

CCEN=/sys/class/qcom-battery/charge_control_en
END_NODE=/sys/class/power_supply/battery/charge_control_end_threshold
START_NODE=/sys/class/power_supply/battery/charge_control_start_threshold

ui_print "*******************************************"
ui_print "  Odin 3 Charge Separation @ 100%"
ui_print "  by KingAether"
ui_print "*******************************************"

mkdir -p $DATADIR
chmod 755 $DATADIR

# ---------------------------------------------------------------
# Preferred: native kernel charge-control thresholds (pmic_glink)
# ---------------------------------------------------------------
if [ -f "$END_NODE" ] && [ -f "$CCEN" ]; then
  ui_print "- Native charge_control interface detected:"
  ui_print "    $CCEN"
  ui_print "    $END_NODE (currently $(cat $END_NODE 2>/dev/null))"
  ui_print "    $START_NODE (currently $(cat $START_NODE 2>/dev/null))"
  ui_print "- Using THRESHOLD mode (works even in deep sleep)"
  MODE=threshold
else
  ui_print "! Native threshold nodes not found, probing legacy nodes..."
  MODE=legacy
fi

# ---------------------------------------------------------------
# Legacy fallback probe (only matters if MODE=legacy)
# ---------------------------------------------------------------
FOUND_NODE=""; FOUND_STOP=""; FOUND_RESUME=""
if [ "$MODE" = "legacy" ]; then
  CANDIDATES="
/sys/class/power_supply/battery/battery_charging_enabled|0|1
/sys/class/power_supply/battery/charging_enabled|0|1
/sys/class/qcom-battery/charging_enabled|0|1
/sys/class/power_supply/battery/charge_disable|1|0
/sys/class/power_supply/battery/batt_slate_mode|1|0
"
  IFS_BAK=$IFS
  IFS='
'
  for line in $CANDIDATES; do
    [ -z "$line" ] && continue
    node=${line%%|*}
    rest=${line#*|}
    if [ -f "$node" ] && [ -z "$FOUND_NODE" ]; then
      FOUND_NODE=$node
      FOUND_STOP=${rest%%|*}
      FOUND_RESUME=${rest#*|}
      ui_print "- Legacy node: $FOUND_NODE"
    fi
  done
  IFS=$IFS_BAK
  [ -z "$FOUND_NODE" ] && ui_print "! No control node found; daemon will dump nodes.txt at boot."
fi

# ---------------------------------------------------------------
# Write default config (preserve existing user config on upgrade)
# ---------------------------------------------------------------
if [ ! -f $CONF ]; then
  cat > $CONF << EOF
# Odin 3 Charge Separation config (by KingAether)
# Battery %% at which charging stops (charge separation engages)
TARGET=100
# Battery %% at which charging resumes (must be < TARGET)
RESUME=97
# Seconds between checks / threshold re-enforcement
POLL=30
# Legacy fallback node override (ignored in threshold mode)
NODE=$FOUND_NODE
NODE_STOP=$FOUND_STOP
NODE_RESUME=$FOUND_RESUME
EOF
  ui_print "- Wrote default config: $CONF"
else
  ui_print "- Kept existing config: $CONF"
  ui_print "  (delete it and reinstall to reset defaults)"
fi

set_perm_recursive $MODPATH 0 0 0755 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/system/bin/charge_sep_daemon 0 0 0755

ui_print "- Tip: if separation never engages at TARGET=100,"
ui_print "  set TARGET=99 in config.conf (some kernels treat"
ui_print "  100 as 'charge fully / feature off')."
ui_print "- Install complete. Reboot to activate."
